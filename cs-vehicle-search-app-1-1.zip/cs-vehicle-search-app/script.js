const vehicles = [
  { plate: "AB 1234", vehicle: "2021 Toyota Vios 1.3 XLE", color: "Super White II", year: "2021" },
  { plate: "CD 1234", vehicle: "2020 Mitsubishi Mirage G4 GLX", color: "Titanium Gray", year: "2020" },
  { plate: "EF 1234", vehicle: "2022 Honda City S CVT", color: "Platinum White", year: "2022" },
  { plate: "GH 1234", vehicle: "2021 Toyota Fortuner", color: "Brilliant Silver", year: "2021" },
  { plate: "IJ 5678", vehicle: "2023 Mitsubishi Xpander", color: "Graphite Gray", year: "2023" },
  { plate: "KL 9012", vehicle: "2024 Toyota Raize", color: "Red Mica Metallic", year: "2024" }
];

const searchInput = document.getElementById("searchInput");
const clearButton = document.getElementById("clearButton");
const resultsList = document.getElementById("resultsList");
const resultCount = document.getElementById("resultCount");
const emptyState = document.getElementById("emptyState");
const modal = document.getElementById("detailsModal");

function normalize(value) {
  return value.toLowerCase().replace(/\s+/g, "");
}

function renderVehicles(data) {
  resultCount.textContent = `${data.length} RESULT${data.length === 1 ? "" : "S"}`;
  resultsList.innerHTML = "";
  emptyState.classList.toggle("hidden", data.length !== 0);

  data.forEach((vehicle, index) => {
    const row = document.createElement("button");
    row.className = "vehicle-row";
    row.type = "button";
    row.setAttribute("aria-label", `View details for ${vehicle.plate}`);

    row.innerHTML = `
      <div class="vehicle-top">
        <span class="plate">${vehicle.plate}</span>
        <span class="color">${vehicle.color}</span>
      </div>
      <div class="vehicle-bottom">
        <span class="vehicle-name">${vehicle.vehicle}</span>
        <span class="arrow">›</span>
      </div>
    `;

    row.addEventListener("click", () => openDetails(vehicle));
    resultsList.appendChild(row);
  });
}

function filterVehicles() {
  const query = normalize(searchInput.value.trim());

  const filtered = !query
    ? vehicles
    : vehicles.filter((item) => {
        const searchable = normalize(
          `${item.plate} ${item.vehicle} ${item.color} ${item.year}`
        );
        return searchable.includes(query);
      });

  renderVehicles(filtered);
}

function openDetails(vehicle) {
  document.getElementById("modalTitle").textContent = vehicle.plate;
  document.getElementById("detailPlate").textContent = vehicle.plate;
  document.getElementById("detailVehicle").textContent = vehicle.vehicle;
  document.getElementById("detailColor").textContent = vehicle.color;
  document.getElementById("detailYear").textContent = vehicle.year;
  modal.classList.remove("hidden");
  document.body.style.overflow = "hidden";
}

function closeDetails() {
  modal.classList.add("hidden");
  document.body.style.overflow = "";
}

searchInput.addEventListener("input", filterVehicles);

clearButton.addEventListener("click", () => {
  searchInput.value = "";
  filterVehicles();
  searchInput.focus();
});

document.querySelectorAll("[data-close-modal]").forEach((element) => {
  element.addEventListener("click", closeDetails);
});

document.getElementById("closeDetails").addEventListener("click", closeDetails);

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeDetails();
});

document.getElementById("profileButton").addEventListener("click", () => {
  alert("CS Saturation\nRole: Field Agent\n\nProfile features can be connected to a real login system in the next version.");
});

renderVehicles(vehicles);
